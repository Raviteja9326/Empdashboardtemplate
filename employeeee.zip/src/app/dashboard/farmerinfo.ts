export interface Farmer {
    ID: number;
    EmployeeName?: string;
    PhoneNo?: number;
    State?: number;
    Country?: number;
}
